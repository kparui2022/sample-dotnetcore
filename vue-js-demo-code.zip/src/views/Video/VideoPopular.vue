<template>
    <div class="video-popular-sec">
        <div class="container">
            <h2>Popular Videos</h2>
            <div class="media-otr vd-popular">
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <VideoContentCard />
                <!-- <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd1.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd2.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd3.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd4.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd5.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>

                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd6.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd7.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd8.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd9.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd10.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>

                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd5.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd1.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd2.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd3.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd4.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>

                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd8.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd6.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd10.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd9.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a>
                <a href="#" class="media-innr">
                    <div class="media-pic">
                        <figure class="img"><img src="@/assets/images/vd7.jpg" alt="" /></figure>
                        <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
                    </div>
                    <h5>‘Semantic Error: The Movie’ Unveils... </h5>
                    <h6>Movie Title</h6>
                    <ul>
                        <li>Jun 04.2022</li>
                        <li>View 13,535</li>
                    </ul>
                </a> -->
            </div>
        </div>
    </div>
</template>

<script>
import VideoContentCard from '@/components/VideoContentCard.vue';
    export default {
    name: "VideoPopular",
    components: { VideoContentCard }
};
</script>