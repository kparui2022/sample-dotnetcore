<template>
    <section class="mypage-sec">
        <div class="container">
            <div class="mypage-wrapper">
                <LeftSidePanel />
                <div class="mypage-rght">
                    <h2>Media</h2>
                    <div class="tab-outr full-wd three">
                        <TabWrapper>
                            <Tabs title="Videos (12)">
                                <div class="media-otr">
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />
                                    <VideoCard />

                                    <!-- <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media1.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>    
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media2.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p> 
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media3.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>       
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media4.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>       
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media5.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>      
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media6.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>      
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media7.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>       
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media8.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>    
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media9.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>      
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media10.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>      
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media11.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>      
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                    <a href="#" class="media-innr">
                                        <div class="media-pic">
                                            <figure class="img"><img src="@/assets/images/media12.jpg" alt="" /></figure>
                                            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 3:10</p>     
                                        </div>
                                        <h5>Title Title Title Title Title Title Titl... </h5>
                                    </a>
                                     -->
                                </div>
                            </Tabs>
                            <Tabs title="Image (12)">
                                <div class="image-otr">
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <ImageCard />
                                    <!-- <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img1.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img2.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img3.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img4.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img5.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img6.jpg" alt="" /></a>
                                    </div>

                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img7.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img8.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img9.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img10.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img11.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img12.jpg" alt="" /></a>
                                    </div>

                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img13.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img14.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img15.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img16.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img17.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img18.jpg" alt="" /></a>
                                    </div>

                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img19.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img20.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img21.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img22.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img23.jpg" alt="" /></a>
                                    </div>
                                    <div class="image-innr">
                                        <a href="#"><img src="@/assets/images/img24.jpg" alt="" /></a>
                                    </div> -->
                                </div>
                            </Tabs>
                            <Tabs title="Poster(12)">
                                <div class="image-otr">
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <PosterCard />
                                    <!-- <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster1.jpg" alt="" /></figure>
                                        <p>Marvel Studios:...</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster2.jpg" alt="" /></figure>
                                        <p>The Courier</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster3.jpg" alt="" /></figure>
                                        <p>The Mauritanian</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster4.jpg" alt="" /></figure>
                                        <p>The Electrical Life o...</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster5.jpg" alt="" /></figure>
                                        <p>The Power of the Dog</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster6.jpg" alt="" /></figure>
                                        <p>Spider-Man: No...</p>
                                    </a>

                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster7.jpg" alt="" /></figure>
                                        <p>Marvel Studios:...</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster8.jpg" alt="" /></figure>
                                        <p>The Courier</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster9.jpg" alt="" /></figure>
                                        <p>The Mauritanian</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster10.jpg" alt="" /></figure>
                                        <p>The Electrical Life o...</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster11.jpg" alt="" /></figure>
                                        <p>The Power of the Dog</p>
                                    </a>
                                    <a href="#" class="image-innr">
                                        <figure class="hgt"><img src="@/assets/images/poster12.jpg" alt="" /></figure>
                                        <p>Spider-Man: No...</p>
                                    </a> -->
                                </div>
                            </Tabs>
                        </TabWrapper>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
import TabWrapper from "@/components/TabWrapper.vue";
import Tabs from "@/components/Tabs.vue";
import LeftSidePanel from "@/components/MyPage/LeftSidePanel.vue";
import VideoCard from "@/components/MyPage/VideoCard.vue";
import ImageCard from "@/components/MyPage/ImageCard.vue";
import PosterCard from "@/components/MyPage/PosterCard.vue";

export default {
  name: 'MyPageMedia',  
  components: {
    Tabs,
    TabWrapper,
    LeftSidePanel,
    VideoCard,
    ImageCard,
    PosterCard
}
};
</script>