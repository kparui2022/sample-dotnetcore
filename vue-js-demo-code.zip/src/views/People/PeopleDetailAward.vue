<template>
     <InnerBanner />
    <div class="people-award-bottom-sec">
    <div class="container">
        <h2 class="mb-10 small-hdr">Awards</h2>
        <div class="people-award-bottom-otr">
            <PeopleAward />
            <PeopleAward />
            <PeopleAward />
            <!-- <div class="people-award-bottom-innr">
                <div class="people-award-bottom-left">
                    <figure><img src="@/assets/images/awd1.jpg" alt="" /></figure>
                </div>
                <div class="people-award-bottom-right">
                    <h4>Doctor Strange in the Multiverse of Madness (2021)</h4>
                    <div class="people-award-bottom-list">
                        <ul>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Academy Awards (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Seattle International Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Phoenix Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Miami Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                        </ul>
                        <a href="#" class="more-list mbl-show">+ more</a>
                    </div>
                </div>
            </div>
            <div class="people-award-bottom-innr">
                <div class="people-award-bottom-left">
                    <figure><img src="@/assets/images/awd2.jpg" alt="" /></figure>
                </div>
                <div class="people-award-bottom-right">
                    <h4>Doctor Strange in the Multiverse of Madness (2021)</h4>
                    <div class="people-award-bottom-list">
                        <ul>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Academy Awards (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Seattle International Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Phoenix Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Miami Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                        </ul>
                        <a href="#" class="more-list">+ more</a>
                    </div>
                </div>
            </div>
            <div class="people-award-bottom-innr">
                <div class="people-award-bottom-left">
                    <figure><img src="@/assets/images/awd3.jpg" alt="" /></figure>
                </div>
                <div class="people-award-bottom-right">
                    <h4>Doctor Strange in the Multiverse of Madness (2021)</h4>
                    <div class="people-award-bottom-list">
                        <ul>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Academy Awards (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Seattle International Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Phoenix Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Miami Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                            <li>
                                <h5>Best Actor</h5>
                                <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                            </li>
                        </ul>
                        <a href="#" class="more-list">+ more</a>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
</div>
  
</template>



<script>
import InnerBanner from '@/components/InnerBanner.vue';
import PeopleAward from '@/components/PeopleAward.vue';
    export default {
    name: "PeopleDetailAward",
    components: { InnerBanner, PeopleAward }
};
</script>