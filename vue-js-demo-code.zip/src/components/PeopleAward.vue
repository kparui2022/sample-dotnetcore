<template>
    <div class="people-award-bottom-innr">
        <div class="people-award-bottom-left">
            <figure><img src="@/assets/images/awd1.jpg" alt="" /></figure>
        </div>
        <div class="people-award-bottom-right">
            <h4>Doctor Strange in the Multiverse of Madness (2021)</h4>
            <div class="people-award-bottom-list">
                <ul>
                    <li>
                        <h5>Best Actor</h5>
                        <p>Academy Awards (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                    </li>
                    <li>
                        <h5>Best Actor</h5>
                        <p>Seattle International Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                    </li>
                    <li>
                        <h5>Best Actor</h5>
                        <p>Phoenix Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                    </li>
                    <li>
                        <h5>Best Actor</h5>
                        <p>Miami Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                    </li>
                    <li>
                        <h5>Best Actor</h5>
                        <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                    </li>
                    <li>
                        <h5>Best Actor</h5>
                        <p>Atlanta Film Festival (2021) <span><img src="@/assets/icons/trophy.svg" alt="" />WINNER</span></p>
                    </li>
                </ul>
                <a href="#" class="more-list mbl-show">+ more</a>
            </div>
        </div>
    </div>
</template>


<script>
    export default {
        name: 'PeopleAward',
    }
</script>