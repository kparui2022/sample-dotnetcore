<template>
    <div class="slider-innr">
            <a href="#" class="slider-pic">
                <figure><img src="@/assets/images/slider-pic1.jpg" alt=""></figure>
                <p>Text Text Text Te... </p>
            </a>
        </div>
</template>



<script>
    export default {
        name: 'SliderContent',
    }
</script>