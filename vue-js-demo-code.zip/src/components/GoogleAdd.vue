<template>
    <div class="goggle-add"
        style="background-image:url(../../../src/assets/images/google-add.jpg)">
        <p>Google Ads</p>
    </div>
</template>


<script>
    export default {
        name: 'GoogleAdd',
    }
</script>