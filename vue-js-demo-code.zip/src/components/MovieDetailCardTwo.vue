<template>
    <div class="movie-detail">
        <figure class="prize-img">
            <img src="@/assets/images/poster.png" alt="award">
        </figure>
        <div class="m-content">
            <span>
                <figure><img src="@/assets/icons/trophy.svg" alt="trophy"></figure>
                <p>WINNER</p>
            </span>
            <h3>Amanda Seyfried</h3>
            <p>Movie title</p>
        </div>
        
    </div>
        <div class="movie-detail">
        <figure class="prize-img">
            <img src="@/assets/images/poster.png" alt="award">
        </figure>
        <div class="m-content">
            <span>
                <figure><img src="@/assets/icons/trophy.svg" alt="trophy"></figure>
                <p>WINNER</p>
            </span>
            <h3>Amanda Seyfried</h3>
            <p>Movie title</p>
        </div>
        
    </div>
    <div class="nominee-content">
        <h4>Nominees</h4>
        <ul>
            <li>
                <p>Kelly Reilly</p><span>Movie title</span>
            </li>
            <li>
                <p>Karen Gillan</p><span>Movie title</span>
            </li>
            <li>
                <p>Bryce Dallas Howard</p><span>Movie title</span>
            </li>
            <li>
                <p>Bryce Dallas Howard</p><span>Movie title</span>
            </li>
        </ul>
    </div>
</template>


<script>
    export default {
        name: 'MovieDetailCardTwo',
    }
</script>