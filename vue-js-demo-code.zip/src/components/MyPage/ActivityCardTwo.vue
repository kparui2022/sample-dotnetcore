<template>
    <div class="activity-box mb-30">
        <div class="act-box-top">
            <h4>Kim Jung-young <span>Jun 20, 2022 </span></h4>
            <span class="tag light">Movie</span>
        </div>
        <div class="approved-inn">
            <span class="text-lft">Approved</span>
            <span class="text-rg">+ 300 P</span>
        </div>
        <div class="approved-txt-otr">
            <h5>Text</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>-</span>
                </div>
                <p>TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextText</p>
            </div>
        </div>
        <div class="approved-txt-otr">
            <h5>Text</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>+</span>
                </div>
                <p>TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextText</p>
            </div>
        </div>
        <div class="approved-inn pt-10">
            <span class="text-lft">Approved</span>
            <span class="text-rg">+ 500 P</span>
        </div>
        <div class="approved-txt-otr">
            <h5>Text</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>+</span>
                </div>
                <p>TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextText</p>
            </div>
        </div>
    </div>
</template>


<script>
    export default {
        name: 'ActivityCardTwo',
    }
</script>