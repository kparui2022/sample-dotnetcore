<template>
    <div class="comm-pic">
        <figure><img src="@/assets/images/image19.jpg" alt="" /></figure>
    </div>
    <div class="comm-txt">
        <div class="comm-txt-top">
            <h4 class="c-hdr"><a href="#">Doctor Strange in the Multiverse of Madness</a></h4>
            <div class="right">
                <div class="date no-mr">
                    <span>June 10. 2021  </span>
                </div>
            </div>
        </div>
        <p>Article text  Article text Article text Article text Article text Article text Article text Article text Article text Article text Article text  Article text Article text Article text Article text Article text Article text Article text Article text Article text Article text  Article text Article text Article text Article text Article text Article text Article text Article text Article text Article text  Article text  Article text </p>
    </div>
</template>


<script>
    export default {
        name: 'FavoriteCard',
    }
</script>
