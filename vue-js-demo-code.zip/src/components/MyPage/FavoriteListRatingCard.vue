<template>
    <div class="comm-pic">
        <figure><img src="@/assets/images/image16.jpg" alt="" /></figure>
    </div>
    <div class="comm-txt">
        <div class="comm-txt-top">
            <div class="rating">
                <h4 class="c-hdr"><a href="#">Christian Bale</a></h4>
                <ul>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star1.svg" alt="" /></a></li>
                    <li>8.5</li>
                </ul>
            </div>
            <div class="right">
                <div class="date no-mr">
                    <span>Jan 01. 1974 ~ </span>
                </div>
            </div>
        </div>
        <ul class="innr-list">
            <li>Batman Begins</li>
            <li>The Dark Knight</li>
            <li>The Dark Knight Rises</li>
            <li>TitThe Prestigele</li>
        </ul>
    </div>
</template>


<script>
    export default {
        name: 'FavoriteListRatingCard',
    }
</script>
