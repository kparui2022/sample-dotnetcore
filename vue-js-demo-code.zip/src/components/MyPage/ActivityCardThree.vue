<template>
    <div class="activity-box">
        <div class="act-box-top">
            <h4>Yumi’s cells <span>Jun 20, 2022 </span></h4>
            <span class="tag light">Webtoons</span>
        </div>
        <p class="wtg">Rejected</p>
        <div class="approved-txt-otr">
            <h5>Poster</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>+</span>
                </div>
                <p>sldkgln3350485.jpg</p>
            </div>
        </div>
        <p class="wtg">Waiting</p>
        <div class="approved-txt-otr">
            <h5>Video</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>+</span>
                </div>
                <p>http://dgsdgoiwnlegn.com</p>
            </div>
        </div>
    </div>
</template>


<script>
    export default {
        name: 'ActivityCardThree',
    }
</script>