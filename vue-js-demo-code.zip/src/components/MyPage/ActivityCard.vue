<template>
    <div class="activity-box mb-8">
        <div class="act-box-top">
            <h4>Yumi’s cells <span>Jun 20, 2022 </span></h4>
            <span class="tag">TV Show</span>
        </div>
        <div class="approved-inn">
            <span class="text-lft">Approved</span>
            <span class="text-rg">+ 300 P</span>
        </div>
        <div class="approved-txt-otr">
            <h5>Text</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>-</span>
                </div>
                <p>TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextText</p>
            </div>
        </div>
        <div class="approved-txt-otr">
            <h5>Text</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>-</span>
                </div>
                <p>TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextText</p>
            </div>
        </div>
        <p class="wtg">Waiting</p>
        <div class="approved-txt-otr">
            <h5>Image</h5>
            <div class="approved-txt-input">
                <div class="symbol">
                    <span>+</span>
                </div>
                <p>dlksjdlg39487.jpg</p>
            </div>
        </div>
    </div>
</template>


<script>
    export default {
        name: 'ActivityCard',
    }
</script>