<template>
    <div class="comm-pic">
        <figure><img src="@/assets/images/image16.jpg" alt="" /></figure>
    </div>
    <div class="comm-txt">
        <div class="comm-txt-top">
            <h4 class="c-hdr"><a href="#">Christian Bale</a></h4>
            <div class="right">
                <div class="date no-mr">
                    <span>Jan 01. 1974 ~ </span>
                </div>
            </div>
        </div>
        <ul class="innr-list">
            <li>Batman Begins</li>
            <li>The Dark Knight</li>
            <li>The Dark Knight Rises</li>
            <li>TitThe Prestigele</li>
        </ul>
    </div>
</template>


<script>
    export default {
        name: 'FavoriteListCard',
    }
</script>
