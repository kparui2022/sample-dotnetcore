<template>
    <div class="comm-pic">
        <figure><img src="@/assets/images/image14.jpg" alt="" /></figure>
    </div>
    <div class="comm-txt">
        <div class="comm-txt-top">
            <h4 class="c-hdr"><a href="#">Kang Tae-oh <span>Extraordinary Attorney Woo</span></a></h4>
            <div class="right">
                <div class="date">
                    <span>June 10. 2021 </span>
                    <span>10:05</span>
                </div>
                <a href="#" class="delete pt-0">
                    <img src="@/assets/icons/delete.svg" class="dark-th" alt="" />
                    <img src="@/assets/icons/delete-blk.svg" class="light-th" alt="" />
                </a>
            </div>
        </div>
        <p>Article text  Article text Article text Article text Article text Article text Article text Article text Article text Article text Article text  Article  </p>
        <h5>replied to <span>Username</span></h5>
    </div>

</template>

<script>
    export default {
        name: 'CommunicationCardTwo',
    }
</script>