<template>
    <div class="comm-pic">
        <figure><img src="@/assets/images/image19.jpg" alt="" /></figure>
    </div>
    <div class="comm-txt">
        <div class="comm-txt-top">
            <div class="rating">
                <h4 class="c-hdr"><a href="#">Doctor Strange in the Multiverse of Madness</a></h4>
                <ul>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star-solid.svg" alt="" /></a></li>
                    <li><a href="#"><img src="@/assets/icons/star1.svg" alt="" /></a></li>
                    <li>8.5</li>
                </ul>
            </div>
            <div class="right">
                <div class="date no-mr">
                    <span>June 10. 2021  </span>
                </div>
            </div>
        </div>
        <p>Article text  Article text Article text Article text Article text Article text Article text Article text Article text Article text Article text  Article text Article text Article text Article text Article text Article text Article text Article text Article text Article text  Article text Article text Article text Article text Article text Article text Article text Article text Article text Article text  Article text  Article text  </p>
    </div>
</template>


<script>
    export default {
        name: 'FavoriteRatingCard',
    }
</script>
