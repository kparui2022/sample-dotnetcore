<template>
    <span><img src="../assets/images/b1.png" alt="born"></span>
    <p>Kim Go-eun</p>
</template>


<script>
    export default {
        name: 'Card',
    }
</script>