<template>
    <a href="#" class="list-content">
        <div class="list-img">
            <img src="@/assets/images/img-1.png" alt="image">
        </div>
        <h3>Episode 1</h3>
        <p class="p-txt">Jun 20, 2022 </p>

    </a>
</template>


<script>
    export default {
        name: 'ImageTextCard',
    }
</script>
