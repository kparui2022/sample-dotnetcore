<template>
    <a href="#" class="media-innr">
        <div class="media-pic">
            <figure class="img"><img src="@/assets/images/vd1.jpg" alt="" /></figure>
            <p><span><img src="@/assets/icons/play-btn.svg" alt="" /></span> 12:10</p>    
        </div>
        <h5>‘Semantic Error: The Movie’ Unveils... </h5>
        <h6>Movie Title</h6>
        <ul>
            <li>Jun 04.2022</li>
            <li>View 13,535</li>
        </ul>
    </a>
</template>


<script>
    export default {
        name: 'VideoContentCard',
    }
</script>