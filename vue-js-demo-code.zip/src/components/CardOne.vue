<template>
    <a href="#" class="list-content">
        <div class="list-img">
        <img src="../assets/images/image-2.png" alt="image">
        </div>
        <span>NEWS</span>
        <h3>Title Title Title v Title Title Title Title Title Title Title Title Title Title Title Title v
        Title Title Title Title Title Title Title Title Title </h3>
        <p class="p-txt">Edited by Hwang Hong Sun Translated by Kim Hoyeun Yumi’s Cells has returned with
        season two. The second…</p>
        <div class="news-date">
        <p>Jun 10, 2022</p>
        </div>
    </a>
</template>


<script>
    export default {
        name: 'CardOne',
    }
</script>