<template>
    <div class="left-image">
        <img src="../assets/images/r1.png" alt="pic">
    </div>
    <div class="right-content">
        <span class="comment">Comments</span>
        <div class="comment-name">
        <h3>Lightyear</h3>
        <p>June 10. 2021 <span>11:10</span></p>
        </div>
        <p>Article text Article text Article text Article text Article text Article text Article text Article text
        Article text Article text Article text Article text Article text Article text Article text Article text
        Article text Article text Article text Article text Article text Article text Article text Article text
        Article text Article text Article text Article text Article text Article text Article text Article text
        Article text Article text Article text Article text Article text Article text Article text Article text
        Article text Article text Article text Article text Article text Article text Article text Article text
        Article text Article text Article text Article text Article text Article text Article text Article text
        Article text Article text Article text Article text </p>
        <div class="user-name">
        <img src="../assets/images/pic.png" alt="pic">
        <p>ilovemovie</p>
        </div>
    </div>
</template>


<script>
    export default {
        name: 'Comments',
    }
</script>