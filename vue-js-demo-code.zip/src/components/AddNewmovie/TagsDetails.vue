<template>
  

    <div class="tags-from-details">
        <div class="page-heading-area">
            <h2>Tags</h2>
        </div>

        <div class="tag-content-area">
            
            <div class="tag-content-list">
                <div class="tags-upper-area">
                    <h4>Genre</h4>
                    <span class="plusicon" @click="isTagModal = true">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.9993 10.668V21.3346M21.3327 16.0013L10.666 16.0013" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
                            <rect x="0.5" y="0.5" width="31" height="31" rx="3.5" stroke="#41444C"/>
                        </svg>
                    </span>
                </div>
                <div class="tags-listings">
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                </div>
            </div>

            <div class="tag-content-list">
                <div class="tags-upper-area">
                    <h4>Subject</h4>
                    <span class="plusicon">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.9993 10.668V21.3346M21.3327 16.0013L10.666 16.0013" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
                            <rect x="0.5" y="0.5" width="31" height="31" rx="3.5" stroke="#41444C"/>
                        </svg>
                    </span>
                </div>
                <div class="tags-listings">
                    <div class="single-tag">The survival stories (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                </div>
            </div>

            <div class="tag-content-list">
                <div class="tags-upper-area">
                    <h4>Material</h4>
                    <span class="plusicon">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.9993 10.668V21.3346M21.3327 16.0013L10.666 16.0013" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
                            <rect x="0.5" y="0.5" width="31" height="31" rx="3.5" stroke="#41444C"/>
                        </svg>
                    </span>
                </div>
                <div class="tags-listings">
                    <div class="single-tag">The survival stories (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>
                </div>
            </div>

            <div class="tag-content-list">
                <div class="tags-upper-area">
                    <h4>Charecter</h4>
                    <span class="plusicon">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.9993 10.668V21.3346M21.3327 16.0013L10.666 16.0013" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
                            <rect x="0.5" y="0.5" width="31" height="31" rx="3.5" stroke="#41444C"/>
                        </svg>
                    </span>
                </div>
                <div class="tags-listings">
                    <div class="single-tag">The survival stories (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">Romance (8) <span><img src="@/assets/icons/close.svg"></span></div>                    
                </div>
            </div>

            <div class="tag-content-list">
                <div class="tags-upper-area">
                    <h4>Place Background</h4>
                    <span class="plusicon">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.9993 10.668V21.3346M21.3327 16.0013L10.666 16.0013" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
                            <rect x="0.5" y="0.5" width="31" height="31" rx="3.5" stroke="#41444C"/>
                        </svg>
                    </span>
                </div>
                <div class="tags-listings">
                    <div class="single-tag">The survival stories (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>               
                </div>
            </div>

            <div class="tag-content-list">
                <div class="tags-upper-area">
                    <h4>Status</h4>
                    <span class="plusicon">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.9993 10.668V21.3346M21.3327 16.0013L10.666 16.0013" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
                            <rect x="0.5" y="0.5" width="31" height="31" rx="3.5" stroke="#41444C"/>
                        </svg>
                    </span>
                </div>
                <div class="tags-listings">
                    <div class="single-tag">The survival stories (10) <span><img src="@/assets/icons/close.svg"></span></div>
                    <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>               
                </div>
            </div>
            
            <a href="" class="saveBtn">Save</a>
        </div>
              
    </div>


 <!-- add tag modal -->

 <div class="new-cast-modal">
    <PopUpModal :isModal="isTagModal">
      <template v-slot:header>
        <h1>Add New Tag</h1>
        <!-- <button @click="isVideoModal = false">
          <img src="@/assets/icons/modal-cross-icon.svg" alt="" />
        </button> -->
      </template>
      <template v-slot:body>

        <div class="add-tag-popbody">
          <div class="form-group">
            <label>Sub Category</label>
            <select class="form-control">
              <option>Hello-1</option>
              <option>Hello-1</option>
              <option>Hello-1</option>
            </select>
          </div>
          <div class="form-group martop16">
            <label>Tags</label>
            <select class="form-control">
              <option>The survival stories (10)</option>
              <option>The survival stories (10)</option>
              <option>The survival stories (10)</option>
            </select>
          </div>
          <div class="tags-listings">
              <div class="single-tag">The survival stories (10) <span><img src="@/assets/icons/close.svg"></span></div>
              <div class="single-tag">The desire. (10) <span><img src="@/assets/icons/close.svg"></span></div>               
          </div>

          <div class="form-group martop24">
            <label>Score</label>
            <div class="score-board">
              <a href="" class="minusbtn">-</a>
              <input type="text" value="5" readonly />
              <a href="" class="plusbtn">+</a>
            </div>
          </div>

        </div>

      </template>
      <template v-slot:footer>
        <div class="button-group">
          <button class="black-outline-btn">Save</button>
          <button class="red-fill-btn" @click="isTagModal = false">
            Cancel
          </button>
        </div>
      </template>
    </PopUpModal>
  </div>





</template>

<script>


import Tabs from "@/components/Tabs.vue";
import TabWrapper from "@/components/TabWrapper.vue";
import PopUpModal from "@/components/Modals/PopUpModal.vue";

export default {
  name: 'TagsDetails',
  components: {
    Tabs,
    TabWrapper,
    PopUpModal,
    
  },  
  data () {
   return {
    shows: false,
    shows1: false,
    isTagModal: false
   }
 },
 

};


</script>

<style></style>
