<template>
    <a href="#" class="vd-innr-content">
        <span>
            <img src="../assets/images/h1.png" alt="video" class="video-img">
            <div class="play-btn">
            <img src="../assets/icons/play.svg" alt="play">
            <p>2:10</p>
            </div>
        </span>
        <p>Title Title Title Title Title Title Title Title... </p>
    </a>
</template>

<script>
    export default {
        name: 'CardThree',
    }
</script>