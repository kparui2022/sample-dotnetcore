<template>
    <ul class="social-icon-list">
        <li>
            <a href="#">
                <img src="@/assets/icons/instagram.svg" class="dark-th" alt="" />
                <img src="@/assets/icons/instagram-blk.svg" class="light-th" alt="" />
            </a>
        </li>
        <li>
            <a href="#">
                <img src="@/assets/icons/Facebook.svg" class="dark-th" alt="" />
                <img src="@/assets/icons/facebook-blk.svg" class="light-th" alt="" />
            </a>
        </li>
    </ul>
</template>


<script>
    export default {
        name: 'SocialIconCard',
    }
</script>

