<template>
    <a href="#" class="list-content">
        <div class="list-img">
        <img src="../assets/images/nr1.png" alt="image">
        </div>
        <div class="pop-count">
        <span>
            <h3>Stranger Things</h3>
            <p><span>Drama</span><span>Mystery</span><span>Sci-Fi & Fantasy</span></p>
            <div class="startxt">
            <div class="md-star">
                <img src="../assets/icons/star.svg" alt="star">
                <img src="../assets/icons/star.svg" alt="star">
                <img src="../assets/icons/star.svg" alt="star">
                <img src="../assets/icons/star.svg" alt="star">
                <img src="../assets/icons/outline-star.svg" alt="star">
            </div>
            <span>8.5</span>
            </div>
        </span>
        </div>

        <div class="news-date">
        <p>Jun 20, 2022 <span>67 episodes</span></p>
        </div>
    </a>
</template>


<script>
    export default {
        name: 'CardFour',
    }
</script>