<template>
    <a href="#">
        <span>
            <img src="/src/assets/images/v1.png" alt="video" class="video-img">
            <div class="play-btn"><img src="/src/assets/icons/play.svg" alt="play">
                <p>2:10</p>
            </div>
        </span>
        <h3>‘Semantic Error: The Movie’ Unveils Its Release Date, Main Poster and Trailer</h3>
        <p>Movie Title</p>
        <div class="news-date">
            <p>View 13,535 <span>Jun 04.2022</span></p>
        </div>
    </a>
</template>


<script>
    export default {
        name: 'VideoCard',
    }
</script>