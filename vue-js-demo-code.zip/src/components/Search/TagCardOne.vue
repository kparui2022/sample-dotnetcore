<template>
    <a href="#">
        <img src="@/assets/images/bad.png" alt="image">
        <div class="main-dta">
            <span>
                <h4>The Bad Bunch</h4>
                <p>June 10. 2021 </p>
            </span>
            <div class="p-content">
                <p>TA white ex-GI goes to a black ghetto to deliver a letter from his
                    buddy, a black soldier who died in Vietnam. When he arrives there he
                    encounters hostility and trouble from all sides.</p>
            </div>
        </div>

    </a>
</template>


<script>
    export default {
        name: 'TagCardOne',
    }
</script>
