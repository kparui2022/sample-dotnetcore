<template>
    <a href="#">
        <img src="@/assets/images/p1.png" alt="image">
        <div class="main-dta">
            <span>
                <h4>Tom Holland <span>Actor</span></h4>
                <p>Jan 01. 1974 ~</p>
            </span>
            <div class="p-content">
                <ul>
                    <li>
                        <p>Avengers: Infinity War</p>
                    </li>
                    <li>
                        <p>Avengers: Endgame</p>
                    </li>
                    <li>
                        <p>Captain America: Civil War</p>
                    </li>
                    <li>
                        <p>Spider-Man: Homecoming</p>
                    </li>
                </ul>
            </div>
        </div>

    </a>
</template>


<script>
    export default {
        name: 'PeopleCard',
    }
</script>