<template>
    <a href="#">
        <img src="@/assets/images/tom-farm.png" alt="image">
        <div class="main-dta">
            <span>
                <h4>Tom at the Farm</h4>
                <p>June 10. 2021 </p>
            </span>
            <div class="status"><span>Completed</span>
                <p>Every Wed,Sat</p>
            </div>
            <div class="p-content">
                <p>A young man travels to an isolated farm for his lover's funeral where
                    he's quickly drawn into a twisted, sexually charged game by his
                    lover's aggressive brother.</p>
            </div>
        </div>

    </a>
</template>


<script>
    export default {
        name: 'TagCardTwo',
    }
</script>
