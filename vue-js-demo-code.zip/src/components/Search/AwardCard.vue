<template>
    <a href="#">
        <img src="@/assets/images/a1.png" alt="image">
        <div class="main-dta">
            <span><h4>Busan International Film Festival Busan International Film Festival</h4> <p>June 10. 2021 </p></span>
            <div class="p-content"><p>Tom the cat and Jerry the mouse get kicked out of their home and relocate to a fancy New York hotel, where a scrappy employee named Kayla will lose her job if she can’t evict Jerry before a high-class wedding at the hotel. Her solution? Hiring Tom to get rid of the pesky mouse.</p></div>
        </div>
    </a>
</template>


<script>
    export default {
        name: 'AwardCard',
    }
</script>