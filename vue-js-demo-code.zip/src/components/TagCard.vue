<template>
    <div class="mb-tag-otr">
        <h2 class="mb-10 small-hdr">Tags</h2>
        <select class="select-style sm">
            <option>Subject</option>
            <option>Subject</option>
            <option>Subject</option>
        </select>
        <ul class="mb-tag-list">
            <li>FRIENDSHIP</li>
            <li>LOVE TRIANGLE</li>
            <li>WORKPLACE</li>
            <li>SLICE OF LIFE</li>
            <li>PERSONAL GROWTH</li>
            <li>GIRL</li>
            <li>ENERGETIC FEMALE LEAD</li>
            <li>LOVE</li>
            <li>BASED ON WEBCOMIC OR WEBTOON</li>
            <li>LIVE ACTION AND ANIMATION</li>
        </ul>
    </div>
</template>


<script>
    export default {
        name: 'TagCard',
    }
</script>