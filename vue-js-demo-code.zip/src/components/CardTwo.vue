<template>
    <a href="#" class="list-content">
        <div class="list-img">
        <img src="../assets/images/t2.png" alt="image">
        </div>
        <p>Thor: Love and Thunder </p>
    </a>
</template>


<script>
    export default {
        name: 'CardTwo',
    }
</script>