<template>
    <div class="article-innr">
        <a href="#" class="article-pic"><img src="@/assets/images/article-pic3.jpg" alt=""/></a>
        <h5>NEWS</h5>
        <h4 class="cc-hdr"><a href="#">‘Yumi’s Cells’ Season 2 Unveils Lovely Pictures of Kim Go Eun an...</a></h4>
        <p class="cc-para">Upcoming tvN series Yumi’s Cells 2 released new pictures of Kim Go Eun an...</p>
        <h6>Jun 10, 2022</h6>
    </div>
</template>


<script>
    export default {
        name: 'NewsCard',
    }
</script>