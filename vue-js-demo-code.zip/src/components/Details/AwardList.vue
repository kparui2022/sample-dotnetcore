<template>
    <div class="awards-lists">
        <div class="a-content">
            <h2>BaekSang Arts Awards(2021)</h2>
            <figure>
                <img src="@/assets/images/l-award1.png" alt="award1">
            </figure>
            <ul>
                <li>
                    <span class="label-txt">Best Actor</span>
                    <p>Kim Go-eun<span><img src="@/assets/icons/award.svg" alt="award">WINNER</span></p>
                </li>
                <li>
                    <span class="label-txt">Best TV Drama</span>
                    <p>-</p>
                </li>
                <li>
                    <span class="label-txt">Best Actress</span>
                    <p>Kim Go-eun</p>
                </li>
                <li>
                    <span class="label-txt">Best Actress</span>
                    <p>Kim Go-eun</p>
                </li>
                <li>
                    <span class="label-txt">Best Actor</span>
                    <p>Kim Go-eun<span><img src="@/assets/icons/award.svg" alt="award">WINNER</span></p>
                </li>
                <li>
                    <span class="label-txt">Best TV Drama</span>
                    <p>-</p>
                </li>
                <li>
                    <span class="label-txt">Best Actress</span>
                    <p>Kim Go-eun</p>
                </li>
                <li>
                    <span class="label-txt">Best Actress</span>
                    <p>Kim Go-eun</p>
                </li>
                <li>
                    <span class="label-txt">Best Actor</span>
                    <p>Kim Go-eun<span><img src="@/assets/icons/award.svg" alt="award">WINNER</span></p>
                </li>
                <li>
                    <span class="label-txt">Best TV Drama</span>
                </li>
            </ul>
            <a href="#" class="show-more" >+ more</a>
            <a href="#" class="show-less">- less</a>
        </div>
        
    </div>
</template>


<script>
    export default {
        name: 'AwardList',
    }
</script>