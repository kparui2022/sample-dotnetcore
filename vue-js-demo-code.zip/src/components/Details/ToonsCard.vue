<template>
    <a href="#" class="image-innr">
        <figure class="hgt"><img src="@/assets/images/kd4.jpg" alt="" /></figure>
        <p>Yumi’s Cells</p>
        <p class="sub-para">Artist . Writter</p>
        <div class="no-going">
            <span>On Going</span>
        </div>
    </a>
</template>


<script>
    export default {
        name: 'ToonsCard',
    }
</script>
