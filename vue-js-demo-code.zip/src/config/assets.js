const imgs = {
    logo: ""
  }
  
  
  export default { imgs };