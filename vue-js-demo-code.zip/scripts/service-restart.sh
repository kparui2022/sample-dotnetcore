#!/bin/bash
sudo /etc/init.d/apache2 restart