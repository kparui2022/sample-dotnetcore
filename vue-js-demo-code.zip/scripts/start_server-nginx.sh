#!/bin/bash
service nginx retstart
service php7.4-fpm restart