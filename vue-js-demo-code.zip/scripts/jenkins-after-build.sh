#!/bin/bash
sudo chown -R ubuntu:ubuntu /var/www/11-db-demo/
sudo chmod -R 777 /var/www/11-db-demo/
sudo rm -rf /var/www/11-db-demo/.*
sudo rm -rf /var/www/11-db-demo/*
exit