#!/bin/bash
#scp -i aws-access-key.pem app/dist/ ubuntu@13.235.0.2:/var/www/html/vue-js-test/
sshpass -p "Ol635&zxNxfu" scp -r dist/* root@13.127.196.123:/var/www/11-db-demo/